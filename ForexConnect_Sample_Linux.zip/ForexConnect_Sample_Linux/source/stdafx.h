// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include <stdio.h>
#include <string>
#include <list>
#include <map>
#include <iostream>
#include <fstream>
#include <queue>
#include <cstring>
#include <errno.h>
#include "../include/Order2Go2.h"

// TODO: reference additional headers your program requires here
